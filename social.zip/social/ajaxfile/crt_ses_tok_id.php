<?php

session_start();


$_SESSION['tok_id']=$_POST['token_id'];

?>
