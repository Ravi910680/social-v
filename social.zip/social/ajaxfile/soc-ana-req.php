<?php

$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";
$db="ana_soc";

$ana_soc_conn = mysqli_connect($servername, $username, $password,$db);


$db_2="cnt_info";


$lst_name=json_decode($_POST['list_name']);




$Timezone2 = new DateTimeZone('America/Los_Angeles');
$init_date3 = new DateTime("now", $Timezone2 );


$arr_month=array("01"=>0,"02"=>0,"03"=>0,"04"=>0,"05"=>0,"06"=>0,"07"=>0,"08"=>0,"09"=>0,"10"=>0,"11"=>0,"12"=>0);


$arr_days=array("Sun"=>0,"Mon"=>0,"Tue"=>0,"Wed"=>0,"Thu"=>0,"Fri"=>0,"Sat"=>0);


$arr_hour=array_fill(1, 24, 0);

$all_cnt_dt=array();
$all_cnt_code=array();

$date_arr=array();

$cnt_conn = mysqli_connect($servername, $username, $password,$db_2);


function cnt_dat($conn,$cnt_code,$row_num){

  $loc_arr=array();

$sel_cnt_info="select * from cnt where cnt_code='".$cnt_code."'";


$result = $conn->query($sel_cnt_info);

$row = $result->fetch_assoc();

array_push($GLOBALS['all_cnt_dt'], $row['cnt_name']);

array_push($GLOBALS['all_cnt_code'], $row['cnt_code']);
$loc_arr['title']=$row_num;

$loc_arr['longitude']=(int)$row['cnt_lag'];

$loc_arr['latitude']=(int)$row['cnt_lat'];


$loc_arr['color']="#4a154bd9";

return $loc_arr;

}


function clust_date($date){


$month=explode('-', $date)[1];


$GLOBALS['arr_month'][$month]+=1;


$Timezone = new DateTimeZone('America/Los_Angeles');
$myDateTime = new DateTime($date, $Timezone );


$hr_dt=explode(":", $date,2);



$idx_arr=(int)substr($hr_dt[0],strlen($hr_dt[0])-2,strlen($hr_dt[0]));


if($idx_arr!=0){

 $GLOBALS['arr_hour'][$idx_arr]+=1;
}


 $exp_spc=explode(" ", $myDateTime->format('r'),2);


$GLOBALS['arr_days'][substr($exp_spc[0],0,-1)]+=1;






}




function get_where_fld($data_hold,$flg_dt){



if($flg_dt=="time"){

$init_date_min=new DateInterval('P'.$data_hold.'D');
$init_date_min->invert = 1;
$geted_date=$init_date_obj->add($init_date_min);



$get_dt=$geted_date->format('Y-m-d h:i:s');



return "where acc_date>=STR_TO_DATE('".$get_dt."', '%Y-%m-%d %H:%i:%s')";


}else{





}



}














function jsn_enc($arr_val){

$loc_arr=array();

foreach ($arr_val as $key => $value) {
  array_push($loc_arr, $value);

}


return json_encode($loc_arr);


}


function conv_date_form($date){


$newDate = date("y-m-d H", strtotime($date));


return $newDate;


}


function get_where_fld_new($filt_opt){





if($filt_opt[0]=="time"){

if($filt_opt[1]=="in-time"){


$date=conv_date_form($filt_opt[2]);

$str_ret_where_fld="acc_date='".$date."'";


}else{


$date_arr=explode("#", $filt_opt[2]);

$date_1=conv_date_form($date_arr[0]);
$date_2=conv_date_form($date_arr[1]);

$str_ret_where_fld="acc_date>='".$date_1."' and acc_date<='".$date_2."'";


}






}else if($filt_opt[0]=="type"){





}else{


$json_cnt_sel=json_decode($filt_opt[2]);

	if($filt_opt[1]=="cnt-sel"){


foreach ($json_cnt_sel as $key => $value) {
	

$str_ret_where_fld.="ip_dt='".$value."' or ";

}




	}else{



foreach ($json_cnt_sel as $key => $value) {
	

$str_ret_where_fld.="ip_dt <> '".$value."' or ";

}



	}



$str_ret_where_fld=substr($str_ret_where_fld,0,-3);


}


return $str_ret_where_fld;


}





function date_init_function_min_max($conn){



$sel_date_query="select min(acc_date),max(acc_date) from `".$GLOBALS['list_name']."`";

$result=$conn->query($sel_date_query);


$row = $result->fetch_assoc();

array_push($GLOBALS['date_arr'], $row['min(acc_date)']);
array_push($GLOBALS['date_arr'],$row['max(acc_date)']);


}




$filt_cnd_str="";






$filt_opt=$_POST['filt_opt'];



$filt_opt=json_decode($filt_opt);





foreach ($lst_name as $key => $value) {
  
$list_name=$value;



if(count($filt_opt)==0){




$sel_data="select DISTINCT ip_dt from `".$list_name."`";

}else{


$filt_cnd_str=get_where_fld_new($filt_opt);

$sel_data="select DISTINCT ip_dt from `".$list_name."` where ".$filt_cnd_str;

}



$cnt_data=array();

































$result = $ana_soc_conn->query($sel_data);

if ($result->num_rows > 0) {
  // output data of each row



date_init_function_min_max($ana_soc_conn);

  while($row = $result->fetch_assoc()) {
    





if(count($filt_opt)==0){

$sel_cnt_dt="select * from `".$list_name."` where ip_dt='".$row['ip_dt']."'";


}else{


$sel_cnt_dt="select * from `".$list_name."` where ip_dt='".$row['ip_dt']."' and ".$filt_cnd_str;

}


$sel_cnt = $ana_soc_conn->query($sel_cnt_dt);




$ret_val=cnt_dat($cnt_conn,$row['ip_dt'],$sel_cnt->num_rows);


array_push($cnt_data, $ret_val);





 while($rw_fr_cnt = $sel_cnt->fetch_assoc()) {

clust_date($rw_fr_cnt['acc_date']);




 }




  }






} else {
  echo "0 results";
}

}





$data_day=jsn_enc($arr_days);

$data_mnt=jsn_enc($arr_month);


$data_hr= jsn_enc($arr_hour);


$val=json_encode($cnt_data);

$all_cnt_dt=array_unique($all_cnt_dt);


$cnt_arr_get=json_encode($all_cnt_dt);


$cnt_arr_code=json_encode($all_cnt_code);

$main_sed_obj=new \stdClass();

$main_sed_obj->day=$data_day;
$main_sed_obj->month=$data_mnt;
$main_sed_obj->hour=$data_hr;
$main_sed_obj->cnt_name=$cnt_arr_get;
$main_sed_obj->cnt_code=$cnt_arr_code;

$main_sed_obj->cnt_dt=$val;

$main_sed_obj->date_hold=json_encode($date_arr);


echo json_encode($main_sed_obj);




?>
