<?php

function httpGet($url)
{
    $ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);
    return $output;
}






function httpPost($url,$params)
{
  $postData = '';
   //create name value pairs seperated by &
   foreach($params as $k => $v)
   {
      $postData .= $k . '='.$v.'&';
   }
   $postData = rtrim($postData, '&');

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_POST, count($postData));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);

    $output=curl_exec($ch);

    curl_close($ch);
    return $output;

}












$url="https://graph.facebook.com/v7.0/me?fields=accounts{id,access_token}&access_token=EAAHjQOYU9S4BAN0IzQc3jqoXIVuzKJSIJITj4iQtkGOZBg4JqhrwLgXzF1Tu6ZBBXFssrR0Y21LuotIhrzszW4ZBSbbpYY30jIaFMxoqXZBsTL1go0l2L7EIcbdC9BbxQfxPwp4fZAp9MFgyP5metJlTV75IKERhmVRjIDbeeIAZDZD";



$get_data=httpGet($url);

$id_arr=json_decode($get_data);

print_r(count($id_arr->accounts->data));


foreach($id_arr->accounts->data as $value){


	if($value->id=="369744070151457"){

$fb_shed_post_url="https://graph.facebook.com/v7.0/".$value->id."/feed";


$param_post=array (
      'scheduled_publish_time' => '2020-07-04T10:10',
      'message' => 'ravigorasiyanowopen',
      'published' => 'false',
    'access_token'=>$value->access_token
    );



$get_data=httpPost($fb_shed_post_url,$param_post);

print_r($get_data);



	}

}



?>
