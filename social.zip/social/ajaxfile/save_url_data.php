<?php



session_start();
require("../confige/social_post.php");




$camp_id=$_POST['camp_name'];

$url_add=$_POST['url'];

$isrt_main_url="https://heptera.me/dash/url_red/?red_url=".$url_add."&camp_id=".$camp_id;

$url_id=$_POST['red_url'];
$isrt_url_data="insert into post_data_url VALUES('$camp_id','$url_id','$isrt_main_url')";




if ($social_post_conn->query($isrt_url_data) === TRUE) {
  echo 1;
}




?>
