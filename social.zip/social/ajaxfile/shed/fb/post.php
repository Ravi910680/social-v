<?php


require("../../../../../confige/social_post.php");
require("test-2.php");


$post_data=$_POST['post_data'];

$tok_arr=json_decode($_POST['fb_tok_arr']);



foreach ($tok_arr as $key => $value) {
	
$post_acc_data=explode("*", $value);


if(json_decode(fb_account_sheduled($post_acc_data[0],$post_acc_data[1],$post_data))->id==null){


 $update_query="update post_que_data set flg_send='1' where token='".$value."'";


if ($social_post_conn->query($update_query) === TRUE) {
 
}



}else{


$update_query="update post_que_data set flg_send='0' where token='".$value."'";


if ($social_post_conn->query($update_query) === TRUE) {

echo "ravi gorasiya";

}




}











}






?>
