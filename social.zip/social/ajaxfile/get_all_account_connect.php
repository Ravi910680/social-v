<?php

    $id=$_GET["id"];


$all_acc_tok=array();



require("../confige/user_connect.php");

require("../confige/multi_connect_db.php");


$sql = "SELECT * FROM userinfo WHERE id='$id' and varflag='1'";


$result=$conn->query($sql);
$count = mysqli_num_rows($result);

$i=0;
while($row = $result->fetch_assoc()) {

$loc_arr=array();

$loc_arr['app_tp']="fb";
$loc_arr['app_tok']=$row['fb'];
$loc_arr['date']="source";

array_push($all_acc_tok, $loc_arr);

$loc_arr_tw=array();
$i=$i+1;

$loc_arr_tw['app_tp']="tw";
$loc_arr_tw['app_tok']=$row['tw'];
$loc_arr_tw['date']="source";

array_push($all_acc_tok, $loc_arr_tw);


}


$sql_for_multi="select * from  multi_soc_acc where id='".$id."'";

$res_arr_acc_dt = $multi_soc_conn->query($sql_for_multi);


while($row = $res_arr_acc_dt->fetch_assoc()) {
    
$loc_arr=array();

$loc_arr['app_tp']=$row['app_id'];
$loc_arr['app_tok']=$row['acc_tok'];
$loc_arr['date']=$row['add_date'];



array_push($all_acc_tok, $loc_arr);

  }


  $all_tok=json_encode($all_acc_tok);


  echo $all_tok;



?>