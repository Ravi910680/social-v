<?php
session_start();

require("../confige/social_post.php");
$id=$_SESSION['id'];


$json_arr=array();

$sel_camp_data_query="select * from camp_soc_hy where id='".$id."'";



$result = $social_post_conn->query($sel_camp_data_query);


  // output data of each row

if($result->num_rows>0){

  while($row = $result->fetch_assoc()) {
    




array_push($json_arr, $row);



  }

}


echo json_encode($json_arr);



?>