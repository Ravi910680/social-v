
<?php
session_start();

$id=$_SESSION['id'];

$mail=$_SESSION['email'];

$up_dir_name=$id."^c29jX2NvZGU=";


?>


<html>
<head>



<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968021/font-owsome/all_nyeyid.css">


</head>


<style>

nav.navbar.navbar-expand-lg.navbar-light{

position:relative !important;
}













.tooltip2 .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  
  /* Position the tooltip */
  position: absolute;
  z-index: 1;
  top: -5px;
  left: 105%;
}

.tooltip2:hover .tooltiptext {
  visibility: visible;
}
.tooltip2 {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black;
}
















.main-con-soc {
    height: 92vh;
    margin: 0px;
}

.main-con-soc-ico {
border-right: 1px solid #d8d3d8;


    width: 20%;
    padding:10px;
}
.main-con-soc-data {
    width: 80%;
    
}

.main_head_data_opt {
    height: 6vh;
    width: 100%;
font-size:15px;
    border-bottom:1px solid #8880881f;
}


.head-of-acc {
    text-align: right;
opacity: 0;

}
.date-soc{
	

	font-weight: 500;
    font-size: 12px;
    color: #8c7c7c;
}


.con_of_data_que {
    padding: 3vh;
    height: 86vh;

}

.sel_data_post_ip {
    width: 100%;

    padding: 10px;
    font-weight: 500;
    font-size: 13px;
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(184, 184, 184);
    border-radius: 4px;
    box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    color: rgb(99, 99, 99);
}

.soc-ico-data {
    padding: 15px;

}
.sel_data_post_ip:hover{
cursor:pointer;


}
.soc-ico-acc-name {
    padding: 5px;
}

.soc-med-con {
    padding: 5px;

border-radius:3px;
}

.soc-med-con:hover{
cursor:pointer;
background:#f2f2f2;

}
.soc-med-con:hover .head-of-acc{

opacity: 0.8;

}

.head-of-acc i:hover{

cursor:pointer;
}




.sed_que_get{

padding: 1vh;

font-weight: 400;
    color: rgb(119, 121, 122);
    font-size: 14px;




}


.sed_que_get:hover{

color:black;
cursor:pointer;

}


.midd-sel-img{

padding:40px;
border: 1px dashed;
width: fit-content;
padding: 40px;
    height: 100px;
    margin: 20px;
}




.act-opt {
    font-weight: 500;
    border-bottom: 3px solid rgb(44, 75, 255);
    color: black;
}



.row{

margin:0px;
}








.rw-dt-of-ana-dash {
    display: inline-block;
    width: 50%;
    }

    .norm-sty-sel-ico {
    background: white;

    }

    .rw-dt-of-ana-dash {
    display: inline-block;
    width: 50%;
    }

    .norm-sty-lst-name {
    
    
    }











.lst_def_name_con {
    max-height: 60vh;
    width: 300px;
    overflow: scroll;
    margin: auto;
    margin-top: 13vh;
    border: 1px solid #c1bdbda3;
    border-radius: 10px;
    text-align: center;
  }


.camp_ana-open:hover{

cursor: pointer;
}

.ana_das_sty{
  padding:10px;
}






.custom-select {
    position: relative;
    font-family: Arial;
    border: 1px solid #868686;
    background: none;
    padding: 0px;
    height: min-content;
  }
.custom-select select {
  display: none; /*hide original SELECT element:*/

}

.select-selected {
  
}

/*style the arrow inside the select element:*/
.select-selected:after {
  position: absolute;
  content: "";
  top: 14px;
  right: 10px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
  border-color: #fff transparent transparent transparent;
}

/*point the arrow upwards when the select box is open (active):*/
.select-selected.select-arrow-active:after {
  border-color: transparent transparent #fff transparent;
  top: 7px;
}

/*style the items (options), including the selected item:*/
.select-items div, .select-selected {
    padding: 8px 16px;
    cursor: pointer;
    user-select: none;
    color: black;
    font-size: 13px;
  }

/*style items (options):*/
.select-items {
    position: absolute;
    border: 1px solid #868686;
    top: 100%;
    left: 0;
    right: 0;
    z-index: 99;
    border-radius: 5px;
    margin-top: 5px;
    background: white;
  }
/*hide the items when the select box is closed:*/
.select-hide {
  display: none;
}

.select-items div:hover, .same-as-selected {
  background-color: rgba(0, 0, 0, 0.1);
}






</style>

<body>


<?php require("../../confige/header/header.html");?>



<div class="main-con-soc row">
	<div class="main-con-soc-ico">

</div>


      <div class="main-con-soc-data">

<div class="main_head_data_opt row">
<div class="sed_que_get act-opt" id="publs_soc_con"> <i class="fad fa-layer-group" style="
    padding-right: 10px;
"></i>
Publish</div>

<div class="sed_que_get" id="soc_ana_con_trg">


<i class="fa-chart-pie-alt fal" style="
    padding-right: 10px;
" aria-hidden="true"></i>


Analyze</div>

</div>




<div class='main-con-dt'>
    <div class="con_of_data_que">
<div class="sel_data_post_ip" data-toggle="modal" data-target="#use_it_app_mod">

What Would You Like To Share

<i class="fal fa-camera-alt" aria-hidden="true" style="
    float: right;
    font-size: 18px;
"></i>

</div>




<div class="main_con_post_data">


<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>
</div>


</div>

<span class="autocomplete-select"></span>






    </div>



















<div class='main-ana-con'>





<div class="head_sel_mn">





  <button class="main-sel-men" >

<i class="far fa-sliders-h"></i>Filter By<i class="far fa-chevron-down"></i>

</button>
  
  <div class="dropdown-menu2" style="">
    
<div class="dp_filt_ana_head">

  <span class="badge badge-pill badge-sel-dp badge-sel-dp_sel" id="time">By Time</span>
  <span class="badge badge-pill badge-sel-dp badge-sel-dp_sel" id="cnt">By Country</span>


</div>

<div class="con_data_ana_filt">

<div class="opt_dt_by_flt">



</div>

<div class="dt-main-con-sel">


</div>


</div>

<div class="foot_sub_ana_filt">

<a class="rem_filt" style="
">Remove</a>
<button class="filt-btn-sub" style="
"><i class="far fa-sliders-h"></i>filter

</button>





</div>



  </div>






<div class="custom-select" style="width:200px;">
  <select id='sel_acc_type_for_filt'>
    <option value="all">All</option>
    <option value="fb">FaceBook</option>
    <option value="tw">Twitter</option>
    <option value="all">All</option>
    
  </select>
</div>




 <div class="date-hold-shw">
    
        <div class='to-date date-hld'>
        
        
        </div>
        
        <span style="padding:20px 0px;">TO</span>
        <div class='frm-date date-hld'>
        
        </div>
    
    </div>

</div>

<div class="con-of-all-modl" style="
    overflow: scroll;
    height: calc(86vh - 86px);
">

<div class="load-container">


<div class="load_con_cht">

<div class='lds-ring lds-color lds-pos-cht'  style=''><div></div><div></div><div></div><div></div></div>

</div>

<div class="load_con_cht" style="
    float: right;
">

<div class='lds-ring lds-color lds-pos-cht'  style=''><div></div><div></div><div></div><div></div></div>
</div>

<div class='hr-ld-con'>


<div class="load_con_cht">


<div class='lds-ring lds-color lds-pos-bg'  style=''><div></div><div></div><div></div><div></div></div>
</div>

</div>


<div class='hr-ld-con'>

<div class="load_con_cht" style="
    height: 500px;
    width: 90%;
">
<div class='lds-ring lds-color lds-pos-bg'  style=''><div></div><div></div><div></div><div></div></div>
</div>

</div>

</div>


<div class="all-cht-con">



<div class="canvas-container">


<canvas class="cv" id="month_chrt" ></canvas>


<canvas class="cv" id="day_chrt" ></canvas>



</div>





<canvas class="bg-chrt"  id="hour_chrt" ></canvas>






</div>
<div id="chartdiv" ></div>







</div>







</div>






<div class="sel-opt-ana-obj" style="">
    
    







<div class="rw-dt-of-ana-dash norm-sty-sel-ico">
    
    <div class="img-ico-side-con">

<img src="https://image.freepik.com/free-vector/growth-analytics-concept-illustration_114360-2926.jpg" >
    
</div>
    
    </div><div class="rw-dt-of-ana-dash norm-sty-lst-name">
    
    <div class="lst_def_name_con" id='sel_soc_ana-hold-bdg'>
    
<div class="lds-ring lds-color lds-pos-bg" style=""><div></div><div></div><div></div><div></div></div>
    </div>
    
    </div>
</div>

































</div>











</div>

<style>

.img-ico-side-con {
    text-align: center;
  }

.sel-opt-ana-obj{
 
display:none;
}


.sel_soc_ana-hold-bdg {
    border: 1px solid #8880888f;
    border-radius: 5px;
}

.sel_soc_ana-hold-bdg {


   
}
span.head-of-sel {
    font-size: 20px;
    font-weight: 500;
    padding-left: 10px;
}
.head-of-ana-sel {
    font-size: 50px;
    padding: 10px;
    color: #4a154bd9;
}

.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}





#chartdiv {
  width: 100%;
  height: 500px;
  overflow: hidden;
}

.canvas-container {
  display: flex;
  width: 40%;
}

.cv {
  width: 100%;
  height: 100%;
  margin: 10%;
}

.bg-chrt{
margin: auto;
max-width: 700px;

}

.form-control:focus{


  box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
}

.head_sel_mn {
    padding: 20px;
height:86px;
border-bottom: 1px solid #8880886b;
    }

   .main-sel-men {
    width: fit-content;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #868686;
    width: 300px;
    text-align: left;
    background: none;
    font-size: 14px;
font-weight: 500;
  }

  i.far.fa-sliders-h {
    padding-right: 10px;

  }
  .fa-chevron-down {
    float: right;
    padding: 2px;

  }
.main-sel-men:focus{

outline: none;
  border: 1px solid #80bdff;

  box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);



}
  .main-sel-men{



  }






  .dropdown-menu2{
z-index: 100000000;
    display: none;
position: absolute;
    background: white;
    width:300px;box-shadow:none;border:1px solid #868686;padding:0px;

    height:250px;

    margin-top: 5px;
    border-radius: 5px;

  }
.dp_filt_ana_head{
padding: 10px;
height:50px;
width: 100%;
border-bottom: 1px solid #86868659;
}

.opt_dt_by_flt{
  padding: 8px;


padding: 10px;
height:40px;
width: 100%;
border-bottom: 1px solid #86868659;

}

.con_data_ana_filt{



height: 150px;

}

.foot_sub_ana_filt{

height:50px;
width: 100%;
border-top: 1px solid #86868659;
}

.badge-sel-dp {
  margin-right: 10px;

    background: none;
    color: #346192;
    height: 30px;
    padding: 9px;
    font-size: 12px;
    border: 1px solid #346192;
    border-radius: 40px;
    }

    .badge_ht{
height: 24px;
    font-size: 10px;
    padding: 6px;
    }

.badge-sel-dp:hover{

cursor: pointer;

}

.act-data-sel{

color: white;
    background: #346192;

}

.act-data-sel-cnt{

color: white;
    background: #346192;
}



.frm-input {
    border-radius: 10px;
    padding-left: 10px;
    height: 40px;
    border: 1px solid rgb(184, 184, 184);

    }

    .at-time-con {
    padding: 20px;

  }

  .dt-main-con-sel {
    height: 110px;
    overflow: scroll;
  }

  .in-bet-time-con {
    padding: 20px;
    height: 110px;
  }
  label{

padding: 10px 0px;

  }

  .cnt-data-sel {
    padding: 10px;
    height: 110px;

  }

  .foot_sub_ana_filt {
    height: 50px;
    width: 100%;
    border-top: 1px solid #86868659;
    padding: 10px;
    text-align: right;
  }

  button.filt-btn-sub {
    height: 30px;
    border: none;
    background: #4a154bd9;
    border-radius: 20px;
    color: white;
    font-weight: 600;
    letter-spacing: 1.4px;
  }

  .filt-btn-sub:hover{

    cursor: pointer;
  }

  button.filt-btn-sub:focus{

    outline: none;
  }


  .load-container{


 
    margin: 0px;
   
padding: 40px;

  }


  .load_con_cht {
    height: 30vh;
    width: 45%;
    display: inline-block;
    
    background: #f2f2f2;
    border-radius: 20px;

  }


  .hr-ld-con {
    text-align: center;
    margin-top: 100px;

  }


  .date-hold-shw {

padding: 10px;

    display: inline-block;
    float: right;

  }
.date-hld{

display: inline-block;

color: #4a154bd9;
font-weight: 600;

}
  
  a.rem_filt {
    padding: 4px;
    float: left;
    font-weight: 800;
    letter-spacing: .6px;
  }

  .rem_filt:hover{

    cursor: pointer;
  }


.main-ana-con {
    height: 86vh;
    overflow: scroll;
display:none;
}









.cont-not-fd-acc-side {
    margin-top: 100px;
    text-align: center;


  }

  img.not-acc-side {
    width: 200px;

  }

  button.btn_hover_clr {
    margin-top: 10px;

        background: none;
    transition: .5s;
    border: 1px solid #e7e8eb;
    padding: 10px;
    border-radius: 5px;
    color: #1a73e8;
    font-size: 13px;
    font-weight: 500;
  }

  

button.btn_hover_clr:hover {
    background: #e8f0fe;
    cursor: pointer;
  }

  .fal{
    padding-left: 10px;
  }



.hover-ico-ana{

}

.ana-show-ico-hov {
    transition: .3s;
    padding: 10px;
    margin-left: auto;
    visibility: hidden;
    opacity: 0;
  }

.row.hover-ico-ana:hover .ana-show-ico-hov {
    visibility: visible;
    transition: visibility 0s, opacity 0.5s linear;
    opacity: 1;

    }
</style>






<?php


function get_curr_time(){


$tz = 'America/Los_Angeles';
$tz_obj = new DateTimeZone($tz);
$today = new DateTime("now", $tz_obj);
$today_formatted = $today->format('Y-m-d H:i:s');

return $today_formatted;

}


?>
















<div id="use_it_app_mod" class="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display:none; padding-left: 0px;" aria-modal="true">
  <div class="modal-dialog modal-dialog-centered" role="document" style="
  min-width:700px; 
">
    <div class="modal-content" style="
    
">
      <div class="modal-header" style="height:70px" ;="">
        <h3 class="modal-title" id="exampleModalCenterTitle" style="
    color: #4a154bd9;
">Create Post</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true"><i class="fal fa-times" aria-hidden="true"></i></span>
        </button>
      </div>



      <div class="modal-body" style="text-align:center;">

    <div class="mod_act_head row" style="
    text-align: left;
    padding: 20px;
height:88px;
">
    <div class="mod_ico_data_part">
    

<i class="fad fa-french-fries" aria-hidden="true" style="
    font-size: 30px;
    color: #4a154bd9;
"></i>
<h3 style="
    display: inline-block;
    padding: 0px 10px;color:black;
" class="app_name_mod">Select post image</h3>

</div>

    </div>

<div class="con-of-sel-img-bd-md">
<form id="upload_img_form" action="https://img.sycista.com/upload_img.php">

<input id="dir_name_for_up" type="text" name="dir_name_up" value="<?php echo $up_dir_name;?>" style="display:none">



<div class="main-div-sel-img row">

<label class="file">

	<div class="con-of-img-sel">

    <div class="midd-sel-img" style="padding: 40px;">
    <i class="fal fa-layer-plus"></i>
</div>

<input class="in_img_data" type="file" name="pic[]" id="file" aria-label="File browser example" accept="image/*" multiple="" style="display:none;">
<span class="file-custom"></span>

</div>
</div>

</label>

</div>






</form>
</div>

<div class="add_text_op_post ">


<textarea id="soc-post-text"></textarea>

<div class="back-img-soc">






</div>


</div>


<div class="sel_opt_data_mod" style="display:none;">

<label style="font-weight:450;color:black;letter-spacing:0.6px;">Create list</label>
<input class="modal-input" id="name_camp_txt" type="text" style="border-radius: 10px;padding-left:10px;height:40px;width:100%;border:1px solid rgb(184, 184, 184);" required="">

<div class='sel_soc_ico'>


</div>

<label style="font-weight:450;color:black;letter-spacing:0.6px;">Set Time To Post</label><br>


<input type="datetime-local" class="frm-input" id="date_time_sel" min="<?php echo get_curr_time();?>">
</div>


<div class="modal-ftr-nxt">
    
        <button class="modal-btn-desg">Add text<i class="fad fa-arrow-circle-right" aria-hidden="true"></i></button>
    
    </div>  
    </div>
  </div>
</div>


<style>



.main_con_post_data {
    height: 68vh;
    margin: 3vh;
overflow:scroll;

text-align:center;

}




.sel_soc_ico {

max-height: 200px;
    overflow: scroll;
    padding: 20px 0px;
}

.badge:hover{
cursor:pointer;
}

.badge-dark-active{
background:#4a154bd9 !important;
color:white !important;


}







.sel_opt_data_mod {
    padding: 40px;

}
.modal-input:focus{

outline: none;
 
    box-shadow: inset 0 0 0 2px #4a154bd9;

}

label {
    color: #4a154bd9;
    font-weight: 500;
padding: 4px 0px;
}
.camp_name_txt {
    padding: 20px 0px;
    width: 400px;
}
input#name_camp_txt {
border: 1px solid #ced7df;
    height: 40px;
    padding: 10px;
    width: 400px;
color: black;
}
.modal-ftr-nxt {




    text-align: right;
    padding: 20px;}

button.modal-btn-desg {
    border: none;
    background: none;
    color: #4a154bd9;
    font-weight: 600;

}
.modal-btn-desg:hover{
cursor:pointer;
}

.midd-sel-img:hover{

cursor:pointer;


}
i.fad.fa-arrow-circle-right {
    padding-left: 10px;

}
.main-div-sel-img {
    
height: 156px;
    overflow-y: scroll;

}


.count-span-con {
    text-align: right;
}


img.img-pre-tg-img {
    height: 100px;
    width: 100px;
margin: 20px;
}

i.fal.fa-layer-plus {
    color: #4a154bd9;

}

.img-pre-tg-img{

cursor:pointer;
}
.frm-input{


border-radius: 10px;
    padding-left: 10px;
    height: 40px;
    border: 1px solid rgb(184, 184, 184);


}





.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.add_text_op_post {
    
display:none;  
margin:20px;
}



textarea#soc-post-text {
   
    padding: 20px;
    width: 100%;
    border: 1px solid #00000085;
    border-radius: 2px;
border-bottom: none !important;
border-color: #ced7df;

}



textarea#soc-post-text:focus {
    border: none;
    outline: none;
    border: 1px solid #00000085;

border-color: #ced7df;

}

.back-img-soc {
    padding: 10px;
    border: 1px solid #00000085;
    border-top: none;
    color: #4a154b61;
    font-weight: 500;
    font-size: 14px;
border-color: #ced7df;
}
.badge-dark {
    color: #4a154bd9;
    background: white;
    margin: 10px;
    white-space: nowrap;
    overflow: hidden !important;
    text-overflow: ellipsis;

    max-width: 300px;
    margin: auto;
}

.back-btn-txt-edt{
border: none;
    background: none;
    color: #4a154bd9;
    font-weight: 600;
}

.ana-show-ico-hov{

padding: 10px;
    margin-left: auto;

}




.main-camp-data.row {
    width: 70%;
    background-color: rgb(255, 255, 255);
    border: 1px solid rgb(184, 184, 184);
    border-radius: 4px;
    box-shadow: rgba(0, 0, 0, 0.16) 0px 1px 4px;
    color: rgb(99, 99, 99);
    padding: 10px;
margin: 20px auto;

text-align:left;

}
.txt-data-post {
    width: 60%;
    padding: 10px;
    overflow: scroll;
    color: black;

    }


    .img-data-post {
    overflow-x: scroll;
    width: 40%;
   
    padding: 10px;

}


.ana_con_data {
    width: 100%;
    text-align: right;
}

a.href-data {
    padding-right: 20px;
    color: #4a154bd9;

    }

.div-con-dat {
    text-align: left;
    width: 50%;
    font-weight: 600;
    font-size: 12px;
    padding: 5px;
    color: #8c7c7cbf;
}



a.hepta-href-post {
    font-weight: 400;
    font-size: 14px;
}









.con_txt_for_mdl {
    color: black;
    padding-bottom: 10px;
}

.bottom-btn {
    text-align: center;
    height: 40px;
    background: #5a297747;
    color: #5a2977;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{

cursor:pointer;
}
.not-fd-data {
    color: black;
    text-align: center;
    padding-top: 50px;
}
img.data-of-not-fd {
    width: 300px;
    
}
.post-not-fd-txt {
    margin: 20px 250px;
}
.soc-med-con-act {
    cursor: pointer;
    background: #f2f2f2;
}

</style>




<div class="modal" id="del_post_data" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Confirm DELETE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

<div class="con_txt_for_mdl">
Enter <b>DELETE</b> for DELETE post.


</div>
      <input class="modal-input" type="text" style="height: 40px;
    width: 100%;padding:10px;
    border: 1px solid rgba(36,28,21,0.3);" id="del_post_ip">
        
      </div>
      <div class="modal-footer">
       
        <button type="button" class="bottom-btn" id="con_del_post_btn"><div class="row">Confirm</div></button>
      </div>
    </div>
  </div>
</div>







<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>










<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
<script src="https://www.amcharts.com/lib/4/core.js"></script>
<script src="https://www.amcharts.com/lib/4/maps.js"></script>
<script src="https://www.amcharts.com/lib/4/geodata/worldLow.js"></script>
<script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>








<script type="text/javascript">






//all account info


all_acc_arr_dt=[];








tok_id_of_pre_acc="";
camp_name_flg="";


tot_act_acc=0;



///data-analyze field
//
//
//



array_of_acc_data=[];




flg_acc_ap_fun=0;

list_open=[];











//usr id var


usr_id='<?php echo $id;?>';


















$(document).on("click",".soc-med-con",function(){


$('.soc-med-con').map(function() {
   

  
$(this).removeClass("soc-med-con-act");



});

$(".main_con_post_data").html("");


	token_id=$(this).attr("id");


tok_id_of_pre_acc=token_id;
get_data_of_camp();
$(this).addClass("soc-med-con-act");
get_post_data(tok_id_of_pre_acc);
set_token_ses();
});






function init_head_ico(remove_ele,add_ele){


flg_data_ele=remove_ele;
flg_non_act="fad";
flg_act="fal";



for (var i = 0; i <2; i++) {


$("#"+flg_data_ele).children("i").removeClass(flg_non_act);
$("#"+flg_data_ele).children("i").addClass(flg_act);


if(i==0){

flg_data_ele=add_ele;

flg_non_act="fal";

flg_act="fad";


}

};






}










$(document).on("click","#publs_soc_con",function(){


$("#publs_soc_con").addClass("act-opt");

$("#soc_ana_con_trg").removeClass("act-opt");

flg_acc_ap_fun=0;

init_main_con_dash("main-con-dt");


init_head_ico("soc_ana_con_trg","publs_soc_con");

get_data_of_camp();


append_not_connect_app();



});





















function get_data_of_camp(){


		$.ajax({
    url : 'ajaxfile/get_post_data_tok.php',
    type: 'POST',
    data : {token_id:tok_id_of_pre_acc}
  }).done(function(response){

if(flg_acc_ap_fun==0){
get_post_data(response);


}else{


 list_open=JSON.parse(response);

}

});


}



function get_post_data(get_post_id){

$(".main_con_post_data").html("<div class='loader-main-con'><div class='lds-ring lds-color' style='margin: auto;'><div></div><div></div><div></div><div></div></div></div>");

console.log(get_post_id);
$.ajax({
    url : 'ajaxfile/get_post_data.php',
    type: 'POST',
    data : {get_jsn:get_post_id}
  }).done(function(response){
console.log(response);



str_data_post=txt_data_post_str(JSON.parse(response));

$(".main_con_post_data").html(str_data_post);

});




}





function txt_data_post_str(data_post){

	str_data_post="";

	if(data_post.length!=0){
for (var i = 0; i < data_post.length; i++) {

	str_img_data=find_img_str(data_post[i].img);

url_data=data_post[i].url;
console.log(url_data.substring(0, 4));
if(url_data.substring(0, 4)=="http"){


}else{

url_data="";
}



act_data_str=action_avail_str(data_post[i].flg_send,data_post[i].date_time,data_post[i].post_name);

str_data_post+="<div class='main-camp-data row' ><div class='txt-data-post'>"+data_post[i].text+"<div><a class='hepta-href-post' href='"+url_data+"'>"+url_data+"</a></div></div><div class='img-data-post row'><div style='display: inline-flex;'>"+str_img_data+"</div></div><div class='ana_con_data row'>"+act_data_str+"</div></div>";

};
	}else{


str_data_post='<div class="not-fd-data"><img class="data-of-not-fd" src="https://res.cloudinary.com/heptera/image/upload/v1599894270/home_page/5551_jxwpgu.jpg"><br><button class="btn_hover_clr" data-toggle="modal" data-target="#use_it_app_mod">Create Post<i class="fal fa-edit"></i></button></div>';


	}


return str_data_post;

}










function action_avail_str(flg_stat,date_def,post_name_get){
console.log(flg_stat);


if(flg_stat==1){

str_ret="<div class='div-con-dat'>"+date_def+"</div><div style='width:50%;text-align:right;padding:5px;'><i class='fad fa-chart-pie-alt camp_ana-open'  id='"+post_name_get+"' style='color:#183153'></i></div>";

}else{




str_ret="<div class='div-con-dat'>"+date_def+"<i class='fad fa-layer-group' style='padding-left:20px;color:pink;'></i></div><div style='width:50%;text-align:right;padding: 5px;'><i class='fad fa-trash-alt del_post_trig' tok_id_del='"+tok_id_of_pre_acc+"' post_name='"+post_name_get+"' data-toggle='modal' data-target='#del_post_data' ></i></div>";




}

return str_ret;

}








function find_img_str(data_img){

str_data_img="";
data_img_arr=data_img.split(",");
for (var i = 0; i < data_img_arr.length-1; i++) {
    
str_data_img+="<img class='img-pre-tg-img' src='http://heptera.me/dash/main/studio/ajaxfile/images/"+data_img_arr[i]+"'>"

};

return str_data_img;

}









$(document).on("click",".del_post_trig",function(){

camp_name_flg=$(this).attr("post_name");

  
});




$(document).on("click","#con_del_post_btn",function(){


if($("#del_post_ip").val()=="DELETE"){





	$(this).html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");
send_del_req();


}

});


function send_del_req(){



  $.ajax({
    url : 'ajaxfile/del_post.php',
    type: 'POST',
    data : {token_id:tok_id_of_pre_acc,post_id:camp_name_flg}
  }).done(function(response){


console.log(response);

if(response==1){

$('#del_post_data').modal('hide');
get_data_of_camp();


$("#del_post_ip").val("");
$("#con_del_post_btn").html("Conferm");
}



});

}














data_of_img="";
flg_dt_mod=0;

val_txt_data="";

str_of_sel_acc="";


date_sel="";


url_flg_cnt=0;

arr_acc_data=[];

date_flg=0;


fb_acc_data=[];



$(document).on("change","#date_time_sel",function(){

	val_date=$(this).val();

	
date_flg=1;
	date_sel=val_date;
	console.log(date_sel);
$(this).css("border","2px solid blue");



});









$(document).on("click",".badge-dark",function(){


	val_get_dt=$(this).attr("data-sel-flg");
if(flg_acc_ap_fun==0){
	if(val_get_dt=="true"){


$(this).attr("data-sel-flg","flase");
$(this).addClass("badge-dark-active");

	}else{

		$(this).removeClass("badge-dark-active");
		$(this).attr("data-sel-flg","true");


	}

}else{


	tok_id_of_pre_acc=$(this).attr("get-tok");

get_data_of_camp();


setTimeout(function(){

get_req_data();


}, 3000);

init_main_con_dash("main-ana-con");


}

});
















$(document).on("change",".in_img_data",function(){

	$(".midd-sel-img").remove();

$(".con-of-img-sel").append("<div class='midd-sel-img' style='padding: 40px;'><div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div></div>");


val=$("#upload_img_form");

$('#upload_img_form').each(function(){
  $.ajax({
    
    //Getting the url of the uploadphp from action attr of form 
    //this means currently selected element which is our form 
    url: $(this).attr('action'),
    
    //For file upload we use post request
    type: "POST",
    
    //Creating data from form 
    data: new FormData(this),
    
    //Setting these to false because we are sending a multipart request
    contentType: false,
    cache: false,
    processData: false,
    success: function(data){
console.log(data);

data_of_img+=data+",";
$(".con-of-img-sel").remove();


$(".main-div-sel-img").append("<div class='img-con-pre'  id='"+data+"'><img class='img-pre-tg-img' src='https://img.sycista.com/images/"+data+"' /></div><label class='file'><div class='con-of-img-sel'><div class='midd-sel-img' style='padding: 40px;'><i class='fal fa-layer-plus'></i></div><input class='in_img_data' type='file' name='pic[]' id='file' aria-label='File browser example' accept='image/*' multiple='' style='display:none;'><span class='file-custom'></span></label>");


    }
  
  });



});

});


$(document).on("dblclick",".img-con-pre",function(){
    id_img=$(this).attr("id");
    $(this).remove();
    data_of_img=data_of_img.replace(id_img+",","");
    
    console.log(data_of_img);
  });



$(document).on("click",".modal-btn-desg",function(){
	
	if(flg_dt_mod==1){

		val_txt_data=$("#soc-post-text").val();

		if(val_txt_data.length==0){
			
			

		}else{

			

			urlify(val_txt_data);

			console.log(main_send_obj);
update_mod_con_data();

		}


	
	
	
	}else if(flg_dt_mod==2 ){
		
		
	
if(val_name_post()){


$("#name_camp_txt").css("border","1px solid rgb(184, 184, 184)");


                update_arr_acc_data();


if(arr_acc_data.length>0){


if(date_flg==1){
 
submit_frm_data_post();


}else{

	$("#date_time_sel").css("border","2px solid #ff0000f5");


}

}

}else{


$("#name_camp_txt").css("border","2px solid #ff0000f5");


}





	}else{
update_mod_con_data();

	}
});



function val_name_post(){


  if($("#name_camp_txt").val().length==0){

return 0;

  }else{

    return 1;
  }
}








function update_arr_acc_data(){

	arr_acc_data=[];

$('.badge-dark-active').map(function() {
   

  
tok_data_of_acc=$(this).attr('get-tok');

if(tok_data_of_acc.search("#")==-1){


arr_acc_data.push(tok_data_of_acc);


fb_acc_data.push(tok_data_of_acc);

}else{



arr_acc_data.push(tok_data_of_acc);



}

});





}














main_send_obj={};
function submit_frm_data_post(){


console.log("ravi");

$(".modal-btn-desg").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");    

console.log(url_flg_cnt);

	if(url_flg_cnt==1){

url_send_str=$("#soc-post-text").val().replace(main_send_obj.url,"");


console.log(url_send_str);

}else{

url_send_str=$("#soc-post-text").val();
main_send_obj.url="";


}



console.log(url_send_str);

main_send_obj.post_name=$("#name_camp_txt").val();
	main_send_obj.txt_data_post=url_send_str;
	main_send_obj.img_data_post= data_of_img;

main_send_obj.date_lnc=$("#date_time_sel").val();






console.log(main_send_obj);
$.ajax({
   url : 'ajaxfile/save_social_data.php',
    type: 'POST',
   data : {camp_data:main_send_obj}
 }).done(function(response){

console.log(response);

if(response==2){

$("#name_camp_txt").css("border","2px solid rgba(255, 0, 0, 0.96)");

$(".modal-btn-desg").html("save post");
}else if(response==3){

$("#date_time_sel").css("border","2px solid rgba(255, 0, 0, 0.96)");

$(".modal-btn-desg").html("save post");



}else{






	split_arr=response.split(",");

split_arr[0]=split_arr[0].replace(/(\r\n|\n|\r)/gm,"");
if(main_send_obj.url==""){


}else{
sub_url_data(split_arr[0],split_arr[1]);



}






console.log(split_arr[0]);

sub_que_data(split_arr[0]);



}

});




}













function shed_fb_post(){


post_data_con=main_send_obj;

tok_arr=JSON.stringify(fb_acc_data);



$.ajax({
    url : 'ajaxfile/shed/fb/post.php',
    type: 'POST',
    data : {post_data:post_data_con,fb_tok_arr:tok_arr}
  }).done(function(response){

console.log(response);

});




}


























function sub_que_data(camp_name_send){

camp_data_arr=JSON.stringify(arr_acc_data);


$.ajax({
    url : 'ajaxfile/save_que.php',
    type: 'POST',
    data : {camp_data:camp_data_arr,camp_name:camp_name_send}
  }).done(function(response){

	  
	  
	  
	  
	  
	  console.log(response);



	   setTimeout(function(){window.location.href ="../social/";  }, 3000);


});
}




function sub_url_data(camp_name_send,url_data){




$.ajax({
    url : 'ajaxfile/save_url_data.php',
    type: 'POST',
    data : {url:main_send_obj.url,camp_name:camp_name_send,red_url:url_data}
  }).done(function(response){


main_send_obj.url=url_data;


});
}






















function update_mod_con_data(){

if(flg_dt_mod==0){
	
	$(".back-img-soc").html($(".con-of-sel-img-bd-md").html()+"<div class='count-span-con'><span class='badge badge-pill badge-primary'>280</span></div>");


	
	
		$(".con-of-sel-img-bd-md").remove();
	

	$(".con-of-sel-img-bd-md").css('display','none');
	$(".add_text_op_post").css("display","block");

flg_dt_mod=1;

}else if(flg_dt_mod==1){ 

	  $(".add_text_op_post").css("display","none");
$(".sel_opt_data_mod").css('display','block');


if(str_of_sel_acc.length==0){

str_of_sel_acc=''

}


$(".sel_soc_ico").append("<label style='font-weight:450;color:black;letter-spacing:0.6px;'>Select Account</label><br>"+str_of_sel_acc);	
$(".modal-ftr-nxt").append("<button  class='back-btn-txt-edt' style='float: left;'><i class='fad fa-arrow-circle-left' aria-hidden='true' style='padding-right: 10px;'></i>Go Back</button>");


flg_dt_mod=flg_dt_mod+1;
}


}




$(document).on("click",".back-btn-txt-edt",function(){



 $(".add_text_op_post").css("display","block");
$(".sel_opt_data_mod").css('display','none');
$(".sel_soc_ico").empty();
$(this).remove();
flg_dt_mod=flg_dt_mod-1;
});

///find_url_daat






































function urlify(text) {
  var urlRegex = /(https?:\/\/[^\s]+)/g;
  return text.replace(urlRegex, function(url) {
	  if(url_flg_cnt==0){
main_send_obj.url=url;


url_flg_cnt=1;

	  }else{


	  }
  })
  // or alternatively
  // return text.replace(urlRegex, '<a href="$1">$1</a>')
}
































jsn_data_page=[];


access_fb_token="";
date_fb="";
access_tw_token="";
date_tw="";
 page_fb_data=[];







$( document ).ready(function() {




get_req_for_all_acc_data();





});





function get_req_for_all_acc_data(){




$.ajax({
                url : "./ajaxfile/get_all_account_connect.php",
                type: "GET",
                data : "id="+usr_id
        }).done(function(response){


jsn_data_page=JSON.parse(response);




init_ico_soc_data();



append_not_connect_app();



        });


}



function append_not_connect_app(){

if(jsn_data_page.length==0){


$(".main-con-soc-ico").html('<div class="cont-not-fd-acc-side"> <img class="not-acc-side" src="https://res.cloudinary.com/heptera/image/upload/v1599893702/home_page/page-lost-2100972-0_up2j7l.svg" style="width:100px;"><br> <button class="btn_hover_clr" style=" margin-top: 20px; ">Connect Account<i class="fal fa-external-link"></i></button></div>');
$(".main_con_post_data").html('<div class="cont-not-fd-acc-side"> <img class="not-acc-side" src="https://res.cloudinary.com/heptera/image/upload/v1599893702/home_page/page-lost-2100972-0_up2j7l.svg"><br> <button class="btn_hover_clr" style=" margin-top: 20px; ">Connect Account<i class="fal fa-external-link"></i></button></div>');


$(".sel-opt-ana-obj").html('<div class="cont-not-fd-acc-side"> <img class="not-acc-side" src="https://res.cloudinary.com/heptera/image/upload/v1599893702/home_page/page-lost-2100972-0_up2j7l.svg"><br> <button class="btn_hover_clr" style=" margin-top: 20px; ">Connect Account<i class="fal fa-external-link"></i></button></div>');


}

}





str_app="";











function init_ico_soc_data(){

for (var i = 0; i < jsn_data_page.length; i++) {
	

	if(jsn_data_page[i]['app_tp']=="fb"){
		access_fb_token=jsn_data_page[i]['app_tok'];

		date_fb=jsn_data_page[i]['date'];
init_fb_in_mod();

	}else{


		access_tw_token=jsn_data_page[i]['app_tok'];
		date_tw=jsn_data_page[i]['date'];

tw_init_mod_data(date_tw);



	}

}

}



function tw_init_mod_data(date_tw){

$.ajax({
                url : "../addcontact/emb/tw/get_pro_det.php",
                type: "POST",
                data : "tw_token="+access_tw_token
        }).done(function(response){
jsn_tw_data=JSON.parse(response);


tot_act_acc+=1;

str_of_sel_acc+="<span class='badge badge-dark' data-sel-flg='true'  get-tok='"+access_tw_token+"*"+jsn_tw_data.tw_name+"'>"+jsn_tw_data.tw_name+"     "+date_tw+"</span>";
send_tok=access_tw_token+"*"+jsn_tw_data.tw_name;
init_ico_main_dt(date_tw,jsn_tw_data.tw_name,'v1592641183/twitter_1_wnavck.png',send_tok);


        });




}











































function init_fb_in_mod(){

$.get(`https://graph.facebook.com/v7.0/me?fields=id&access_token=${access_fb_token}`)
            .then((response) => {

	  



init_fb_in_page_mod(response.id);



            })



}


function init_fb_in_page_mod(id_acc){

$.get(`https://graph.facebook.com/v7.0/${id_acc}/accounts?access_token=${access_fb_token}`)
            .then((response) => {

	 
	page_fb_data=response.data;
console.log(page_fb_data);
for (var i = 0; i < page_fb_data.length; i++) {





	if(tok_id_of_pre_acc==""){

		
		tok_id_of_pre_acc=access_fb_token+"*"+page_fb_data[i].id;



		get_post_data(tok_id_of_pre_acc);
	}

tot_act_acc+=1;

str_of_sel_acc+="<span class='badge badge-dark' data-sel-flg='true' get-tok='"+access_fb_token+"*"+page_fb_data[i].id+"'>"+page_fb_data[i].name+"    "+date_fb+"</span>";
send_tok=access_fb_token+"*"+page_fb_data[i].id;
	init_ico_main_dt(date_fb,page_fb_data[i].name,'v1592641066/facebook_2_lw3ko8.png',send_tok);
};




insta_connect_face();

            })



}




function insta_connect_face(){
	



for(k=0;k<page_fb_data.length;k++){

page_id=page_fb_data[k].id;

$.get("https://graph.facebook.com/v7.0/"+page_id+"?fields=instagram_business_account&access_token="+access_fb_token)
            .then((response) => {


insta_id=response.instagram_business_account.id;


if(insta_id.length>0){

$.get("https://graph.facebook.com/v7.0/"+insta_id+"?fields=username,profile_picture_url&access_token="+access_fb_token)
            .then((response) => {



str_of_sel_acc+="<span class='badge badge-dark' data-sel-flg='true' get-tok='"+access_fb_token+"*"+insta_id+"'>"+response.username+"      "+date_fb+"</span>";

  send_tok=access_fb_token+"*"+insta_id;

init_ico_main_dt(date_fb,response.username,'v1592641126/instagram-sketched_wza9vp.png',send_tok);


            })

}

            })

		    


}


}






function init_ico_main_dt(date_f,name_dt,url_img,link_data){

loc_obj={};

loc_obj.date=date_f;
loc_obj.tkn=link_data;
loc_obj.url_img=url_img;
loc_obj.name=name_dt;





all_acc_arr_dt.push(loc_obj);





str_data="<div class='soc-med-con' id='"+link_data+"'><div class='head-of-acc'><i class='fal fa-times' aria-hidden='true'></i></div><div class='row' style='margin: 0px;'><div class='soc-ico-data'><img src='https://res.cloudinary.com/heptera/image/upload/"+url_img+"' height='25'></div><div class='soc-ico-acc-name'><h3 style='margin: 0px;'>"+name_dt+"<div class='date-soc' style=''>"+date_f+"</div></h3></div></div></div>";

$(".main-con-soc-ico").append(str_data);

$("#"+tok_id_of_pre_acc).addClass("soc-med-con-act");

}






cnt_lst="";

cnt_arr_code="";





json_data_country="";

json_day_data="";

json_month_data="";


json_hour_data="";















filt_arr=[];




$(document).on("click",".main-sel-men",function(){



$(".dropdown-menu2").css("display","block");



});




$(document).mouseup(function(e) 
{
    var container = $(".dropdown-menu2");

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) 
    {
        container.hide();
    }
});


arr_of_init_bg_time=['At time','In Between Time'];

arr_of_time_flg=['in-time','in-bet-time'];

arr_of_init_bg_cnt=['Country',"Not Country"];

arr_of_cnt_flg=['cnt-sel','cnt-not-sel'];



function init_badge_val(ele){
 str_ret="";

if(ele=="time"){

for (var i = 0; i < arr_of_init_bg_time.length; i++) {
  str_ret+='<span class="badge badge-pill badge-sel-dp badge-sel-dp_sel badge_ht" id="'+arr_of_time_flg[i]+'">'+arr_of_init_bg_time[i]+'</span>';
};

}else{

for (var i = 0; i < arr_of_init_bg_cnt.length; i++) {
  str_ret+='<span class="badge badge-pill badge-sel-dp badge-sel-dp_sel badge_ht " id="'+arr_of_cnt_flg[i]+'">'+arr_of_init_bg_cnt[i]+'</span>';
};

}

return str_ret;

}


function init_main_badge(main_ele){



$("#"+main_ele).addClass("act-data-sel");



if(main_ele=="time"){





$("#cnt").removeClass("act-data-sel");


str_ret=init_badge_val(main_ele);


$(".opt_dt_by_flt").html(str_ret);

init_time_fun("in-time");

$("#in-time").addClass("act-data-sel");


$("#in-bet-time").removeClass("act-data-sel");

}else{


$("#time").removeClass("act-data-sel");
str_ret=init_badge_val(main_ele);


$(".opt_dt_by_flt").html(str_ret);




init_cnt_fun("cnt-sel");


$("#cnt-sel").addClass("act-data-sel");


$("#cnt-not-sel").removeClass("act-data-sel");




}


}



function init_time_fun(ele){




filt_arr[1]=ele;

$("#"+ele).addClass("act-data-sel");

if(ele=="in-time"){




$("#in-bet-time").removeClass("act-data-sel");

str_add='<div class="at-time-con"> <label>Set Date</label><br> <input type="datetime-local" class="frm-input" id="date_time_sel_one_flt"></div>';

}else{

$("#in-time").removeClass("act-data-sel");
str_add='<div class="dt-main-con-sel"><div class="in-bet-time-con"> <label>To:</label><br> <input type="datetime-local" class="frm-input" id="date_time_sel_due_1"><br> <label>From:</label><br> <input type="datetime-local" class="frm-input" id="date_time_sel_due_2"> </div></div>';


}


$(".dt-main-con-sel").html(str_add);


}



function init_cnt_fun(ele){



filt_arr[1]=ele;


if(ele=="cnt-sel"){

$("#cnt-sel").addClass("act-data-sel");
$("#cnt-not-sel").removeClass("act-data-sel");


}else{


$("#cnt-not-sel").addClass("act-data-sel");
$("#cnt-sel").removeClass("act-data-sel");

}




str_ret='<div class="cnt-data-sel">';

for (var i = 0; i < cnt_lst.length; i++) {
  


str_ret+='<span class="badge badge-pill badge-sel-dp badge_ht badge_sel_cnt" sel-flg="false" id="'+cnt_arr_code[i]+'">'+cnt_lst[i]+'</span>';

};

str_ret+="</div>"


$(".dt-main-con-sel").html(str_ret);


}


function init_badge_get_acc_val(geted_ele){





console.log(geted_ele);

if(geted_ele=="time" || geted_ele=="cnt"){

filt_arr[0]=geted_ele;

init_main_badge(geted_ele);

}else if(geted_ele=="in-time" || geted_ele=="in-bet-time"){




init_time_fun(geted_ele);

}else if(geted_ele=="cnt-sel" || geted_ele=="cnt-not-sel"){


init_cnt_fun(geted_ele);

}


}






$(document).on("click",".badge_sel_cnt",function(){


dt_flg=$(this).attr("sel-flg");

if(dt_flg=="false"){

$(this).addClass("act-data-sel-cnt");
$(this).attr("sel-flg","true");

}else{

$(this).removeClass("act-data-sel-cnt");

$(this).attr("sel-flg","false");

}
});




$(document).on("click",".filt-btn-sub",function(){

if(filt_arr[0]=="time"){

if(filt_arr[1]=="in-time"){

filt_arr[2]=$("#date_time_sel_one_flt").val();


}else{


filt_arr[2]=$("#date_time_sel_due_1").val()+"#"+$("#date_time_sel_due_2").val();

}

}else{

loc_arr_cnt=[];

$('.act-data-sel-cnt').map(function() {
   

  loc_arr_cnt.push($(this).attr("id"));




});



filt_arr[2]=JSON.stringify(loc_arr_cnt);




}



get_req_data();





});








$(document).on("click",".badge-sel-dp_sel",function(){

var id_att=$(this).attr("id");

console.log("ravi");






init_badge_get_acc_val(id_att);


});





$('.dropdown-menu').click(function(e) {
   $(".btn-group").addClass("open");

$(".btn-group").children("button").attr("aria-expanded","false");

});
















var colorSet = new am4core.ColorSet();




function get_map_data(){




am4core.ready(function() {

// Themes begin
am4core.useTheme(am4themes_animated);
// Themes end

// Create map instance
var chart = am4core.create("chartdiv", am4maps.MapChart);

// Set map definition
chart.geodata = am4geodata_worldLow;

// Set projection
chart.projection = new am4maps.projections.Miller();

// Create map polygon series
var polygonSeries = chart.series.push(new am4maps.MapPolygonSeries());

// Exclude Antartica
polygonSeries.exclude = ["AQ"];

// Make map load polygon (like country names) data from GeoJSON
polygonSeries.useGeodata = true;

// Configure series
var polygonTemplate = polygonSeries.mapPolygons.template;
polygonTemplate.tooltipText = "{name}";
polygonTemplate.polygon.fillOpacity = 0.6;


// Create hover state and set alternative fill color
var hs = polygonTemplate.states.create("hover");
hs.properties.fill = chart.colors.getIndex(0);

// Add image series
var imageSeries = chart.series.push(new am4maps.MapImageSeries());
imageSeries.mapImages.template.propertyFields.longitude = "longitude";
imageSeries.mapImages.template.propertyFields.latitude = "latitude";
imageSeries.mapImages.template.tooltipText = "{title}";
imageSeries.mapImages.template.propertyFields.url = "url";

var circle = imageSeries.mapImages.template.createChild(am4core.Circle);
circle.radius = 3;
circle.propertyFields.fill = "color";

var circle2 = imageSeries.mapImages.template.createChild(am4core.Circle);
circle2.radius = 3;
circle2.propertyFields.fill = "color";


circle2.events.on("inited", function(event){

  
  

  data_cnt=event.target.tooltipDataItem._dataContext.title;

  r_for_cnt=Math.log(data_cnt)+3;



  event.target.radius=r_for_cnt;


animateBullet(event.target);

})


function animateBullet(circle) {

anim=circle.radius*1.5;

    var animation = circle.animate([{ property: "scale", from: 1, to: anim}, { property: "opacity", from: 1, to: 0 }], 1000, am4core.ease.circleOut);
    animation.events.on("animationended", function(event){
      animateBullet(event.target.object);
    })


}


imageSeries.data = JSON.parse(json_data_country);



}); // end am4core.ready()






}








$(document).on("click",".camp_ana-open",function(){


$("#publs_soc_con").removeClass("act-opt");

$("#soc_ana_con_trg").addClass("act-opt");


init_head_ico("publs_soc_con","soc_ana_con_trg");


init_main_con_dash("main-ana-con");


list_open.push($(this).attr('id'));


get_req_data();

});

$(document).on("click",".rem_filt",function(){


filt_arr=[];


get_req_data();

})



function init_main_con_dash(passed_ele){

list_open=[];
filt_arr=[];
$(".main-con-dt").css("display","none");

$(".main-ana-con").css("display","none");

$(".sel-opt-ana-obj").css('display',"none");


$("."+passed_ele).css('display',"block");




}













$(document).on("click","#soc_ana_con_trg",function(){

$("#publs_soc_con").removeClass("act-opt");

$("#soc_ana_con_trg").addClass("act-opt");


init_head_ico("publs_soc_con","soc_ana_con_trg");

	flg_acc_ap_fun=1;


init_main_con_dash("sel-opt-ana-obj");



console.log(all_acc_arr_dt);


init_ana_dash_data();




});





function init_ana_dash_data(){






$.get( "./ajaxfile/get_all_post_name.php", function( data ) {
 
  
all_post_data=JSON.parse(data);

str_ret_dt="";



for (var i = 0; i < all_post_data.length; i++) {

data_per_acc=all_post_data[i];

name_dec=atob(data_per_acc['post_name'].split('^')[1]);

  str_ret_dt+='<div class="badge-dark camp_ana-open ana_das_sty" id="'+data_per_acc['post_name']+'"><div class="row hover-ico-ana" style="margin: 0px;"><div class="soc-ico-acc-name"><h3 style="margin: 0px;">'+name_dec+'<div class="date-soc" style="">'+data_per_acc['date_time']+'</div></h3></div><div class="ana-show-ico-hov" style="  "><img src="https://www.flaticon.com/svg/static/icons/svg/3103/3103222.svg" height="32" style=" "></div></div></div>';
};



console.log(str_ret_dt);


$("#sel_soc_ana-hold-bdg").html(str_ret_dt);



});





}











function get_req_data(){

list_loc_open=JSON.stringify(list_open);
jsn_flt=JSON.stringify(filt_arr);



$("#chartdiv").css("opacity","0");
$(".all-cht-con").css("display","none");

$(".load-container").css("display","block");

$.ajax({
    url : './ajaxfile/soc-ana-req.php',
    type: 'POST',
    data : {filt_opt:jsn_flt,list_name:list_loc_open}
  }).done(function(response){


console.log(response);

parse_json_data(response);

});







}



function parse_json_data(passed_dt){

json_get_dt=JSON.parse(passed_dt);


date_arr=JSON.parse(json_get_dt['date_hold']);


console.log(date_arr[0]);

$(".to-date").html(date_arr[0]);
$(".frm-date").html(date_arr[1]);


cnt_lst=JSON.parse(json_get_dt['cnt_name']);
cnt_arr_code=JSON.parse(json_get_dt['cnt_code']);


json_data_country=json_get_dt['cnt_dt'];
json_day_data=json_get_dt['day'];

json_month_data=json_get_dt['month'];


json_hour_data=json_get_dt['hour'];

console.log(json_data_country);


get_cht_mnt();

get_cht_day();

get_cht_hour();


get_map_data();


$(".load-container").css("display","none");
$(".all-cht-con").css("display","block");
$("#chartdiv").css("opacity","10");

}







function get_cht_mnt(){



loc_dt=JSON.parse(json_month_data);


var ctx = document.getElementById('month_chrt').getContext('2d');
var chart = new Chart(ctx, {


type: 'line',
    data:{
    labels: ["Jan", "Feb", "Mar", "Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"],
   
   datasets:[{
    label:"interact",
    fontColor:"#fff",
    backgroundColor: '#4a154b3b',
            borderColor: '#4a154bd9',
            borderWidth:1,

data:loc_dt

   }]
  
     


  },
  options: {
        title: {
            display: true,
            text: 'Month Wise Interaction',
            position:"bottom",
            fontColor:"#4a154bd9"
        }
    }





});



}



function get_cht_day(){


loc_dt=JSON.parse(json_day_data);


var ctx_day = document.getElementById('day_chrt').getContext('2d');


var chart_day = new Chart(ctx_day, {


type: 'line',
    data:{
    labels: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
   
    fontColor:"#fff",
   datasets:[{
label:"interact",
    backgroundColor: '#ffffff08',
            borderColor: '#4a154bd9',
            borderWidth:1,

data:loc_dt

   }]
  
     


  },
  options: {
        title: {
            display: true,
            text: 'Day Wise Interaction',
            position:"bottom",
            fontColor:"#4a154bd9"
        }
    }





});




}


function get_cht_hour(){


loc_dt=JSON.parse(json_hour_data);

var ctx_hour = document.getElementById('hour_chrt').getContext('2d');


var chart_hour = new Chart(ctx_hour, {


type: 'bar',
    data:{
    labels: ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24'],
   
    fontColor:"#fff",
   datasets:[{
label:"interact",
    backgroundColor: '#4a154b3b',
            borderColor: '#4a154bd9',
            borderWidth:1,

data:loc_dt

   }]
  
     


  },
  options: {
        title: {
            display: true,
            text: 'Hour Wise Interaction',
            position:"bottom",
            fontColor:"#4a154bd9"
        }
    }





});


}

















































var x, i, j, l, ll, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
l = x.length;
for (i = 0; i < l; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  ll = selElmnt.length;
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 1; j < ll; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h, sl, yl;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        sl = s.length;
        h = this.parentNode.previousSibling;
        for (i = 0; i < sl; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            yl = y.length;
            for (k = 0; k < yl; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, xl, yl, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  xl = x.length;
  yl = y.length;
  for (i = 0; i < yl; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < xl; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);










//init all fucntion called





</script>




</body>




















